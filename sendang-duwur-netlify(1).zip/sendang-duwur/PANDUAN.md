# Panduan Online di Netlify (tanpa terminal, tanpa Node.js)

Yang kamu butuhkan: akun **GitHub**, **Netlify**, dan **TiDB Cloud** (ketiganya gratis).
Isi zip ini:
- `public/` → situsmu (`index.html`) dan halaman login (`login.html`)
- `netlify/functions/api.mjs` → seluruh backend
- `netlify.toml`, `package.json` → pengaturan, jangan diubah

## 1. Buat database MySQL gratis (TiDB Cloud)
1. Daftar di **tidbcloud.com**, lalu buat cluster **Starter** (gratis). Pilih region Singapore atau terdekat.
2. Buka cluster → klik **Connect**. Cari bagian koneksi umum (General / "Connect with") dan klik **Generate Password**. Simpan password-nya.
3. Dari halaman itu catat 4 hal: **Host**, **Port** (biasanya 4000), **User**, **Password**. Nama database biasanya `test`.
4. Susun satu alamat dengan pola ini:
   ```
   mysql://USER:PASSWORD@HOST:4000/test
   ```
   Ganti USER, PASSWORD, HOST dengan punyamu. Kalau password mengandung simbol seperti `@` atau `/`, ganti password-nya (Reset Password) sampai hanya huruf dan angka.
   **Tabel tidak perlu dibuat manual.** Semuanya dibuat otomatis saat situs dibuka pertama kali.

## 2. Taruh file di GitHub
1. Di github.com klik **New repository**, beri nama `sendang-duwur`, lalu **Create**.
2. Klik **uploading an existing file**, ekstrak zip ini di laptopmu, lalu seret **semua isinya** (folder `public`, folder `netlify`, `netlify.toml`, `package.json`, `.gitignore`) ke halaman itu. Klik **Commit changes**.
   Pastikan `netlify.toml` dan `package.json` ada di halaman paling depan repo, bukan di dalam folder lain.

## 3. Hubungkan ke Netlify
1. Di netlify.com: **Add new site → Import an existing project → GitHub**, pilih repo `sendang-duwur`.
2. Biarkan kolom build apa adanya (sudah diatur oleh `netlify.toml`). Klik **Deploy**.
3. Setelah itu buka **Site configuration → Environment variables → Add a variable**, tambahkan:

| Nama | Isi |
|---|---|
| `DATABASE_URL` | alamat dari langkah 1.4 |
| `ADMIN_EMAIL` | emailmu (akan jadi akun admin) |
| `DEMO_STAMPS` | `1` |

4. Buka **Deploys → Trigger deploy → Deploy site** supaya pengaturan terbaca.

## 4. Coba
Buka alamat situs `https://namamu.netlify.app` → klik **Masuk** → daftar pakai email yang sama dengan `ADMIN_EMAIL`.
Cek juga `https://namamu.netlify.app/api/health`: kalau tampil `{"ok":true,...}` berarti database nyambung.
Kalau tampil pesan error, bacalah, biasanya `DATABASE_URL` salah ketik.

## Catatan penting untuk lomba
- Kalau backend bermasalah, situs **tetap bisa dibuka**. Stempel tersimpan di perangkat pengunjung (seperti sebelumnya), hanya fitur akun yang mati.
- `DEMO_STAMPS=1` artinya tombol "Cap stempel" langsung sah, cocok untuk demo juri. Untuk versi sungguhan, ubah jadi `0`, buka `/api/admin/qr` saat login sebagai admin untuk mengambil URL QR tiap lokasi.
- Login Google opsional: isi `GOOGLE_CLIENT_ID` dan `GOOGLE_CLIENT_SECRET`, redirect URI = `https://namamu.netlify.app/api/auth/google/callback`.
